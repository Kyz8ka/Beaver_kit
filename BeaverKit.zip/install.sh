#!/usr/bin/env bash
set -e
echo "================================================"
echo "  BeaverKit v3.0 - Linux/macOS Installer"
echo "  t.me/Beaver_kit"
echo "================================================"
echo

# [1/4] Python
echo "[1/4] Checking Python..."
if command -v python3 &>/dev/null; then PY=python3
elif command -v python &>/dev/null; then PY=python
else
    echo "[!] Python not found!"
    if command -v apt &>/dev/null; then
        sudo apt install -y python3 python3-pip; PY=python3
    elif command -v pacman &>/dev/null; then
        sudo pacman -S --noconfirm python python-pip; PY=python3
    elif command -v dnf &>/dev/null; then
        sudo dnf install -y python3 python3-pip; PY=python3
    else
        echo "    Download Python 3.9+ from python.org"; exit 1
    fi
fi
echo "    Version: $($PY --version)"

# [2/4] pip
echo "[2/4] Upgrading pip..."
$PY -m pip install --upgrade pip --quiet 2>/dev/null || true

# [3/4] Dependencies
echo "[3/4] Installing dependencies..."
DEPS="PyQt6 requests beautifulsoup4 psutil phonenumbers"
if $PY -m pip install $DEPS --quiet 2>/dev/null; then
    echo "    OK"
elif $PY -m pip install $DEPS --quiet --break-system-packages 2>/dev/null; then
    echo "    OK (break-system-packages)"
elif $PY -m pip install $DEPS --quiet --user 2>/dev/null; then
    echo "    OK (user install)"
else
    echo "[!] Auto-install failed. Try manually:"
    echo "    pip install PyQt6 requests beautifulsoup4 psutil"
fi

# [4/4] Launch
echo "[4/4] Launching BeaverKit..."
echo
echo "================================================"
echo "  Keep this terminal open (minimize, don't close)"
echo "================================================"
$PY main.py

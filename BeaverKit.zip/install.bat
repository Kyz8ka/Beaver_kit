﻿@echo off
chcp 65001 >nul
title BeaverKit v3.0 - Installer
color 0A
cls

echo.
echo  +-------------------------------------------------------+
echo  ^|   BEAVER KIT v3.0  -  Windows Installer            ^|
echo  ^|              t.me/Beaver_kit                         ^|
echo  +-------------------------------------------------------+
echo.
timeout /t 1 /nobreak >nul

echo  [..............................] 0%% - Starting...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [!] Python not found!
    echo      Download Python 3.11+ from python.org
    echo      Check "Add to PATH" during install, then rerun.
    pause
    start https://www.python.org/downloads/
    exit /b 1
)
for /f "tokens=*" %%i in ('python --version') do echo  [OK] %%i found
echo.
timeout /t 1 /nobreak >nul

echo  [#######.......................] 25%% - Upgrading pip...
python -m pip install --upgrade pip --quiet --disable-pip-version-check
echo  [OK] pip upgraded
echo.
timeout /t 1 /nobreak >nul

echo  [##############................] 50%% - Installing PyQt6...
echo  Please wait - PyQt6 is large (~80 MB)...
python -m pip install "PyQt6>=6.4" "PyQt6-Qt6>=6.4" "PyQt6-sip" --quiet
if %errorlevel% neq 0 python -m pip install "PyQt6>=6.4" --quiet --user
echo  [OK] PyQt6 installed
echo.
timeout /t 1 /nobreak >nul

echo  [#####################.........] 75%% - Installing libraries...
python -m pip install requests beautifulsoup4 psutil phonenumbers --quiet
if %errorlevel% neq 0 python -m pip install requests beautifulsoup4 psutil phonenumbers --quiet --user
echo  [OK] Libraries installed
echo.
timeout /t 1 /nobreak >nul

echo  [############################..] 90%% - Checking...
python -c "import PyQt6; import requests; import psutil" >nul 2>&1
if %errorlevel% neq 0 (
    echo  [!] Something went wrong. Try manually:
    echo      python -m pip install PyQt6 requests psutil --user
    pause
    exit /b 1
)
echo  [OK] All components OK
echo.

echo  [##############################] 100%% - DONE!
echo.
echo  +-------------------------------------------------------+
echo  ^|  [OK] BeaverKit v3.0 installed!                    ^|
echo  ^|  Minimize this window - do NOT close it!             ^|
echo  +-------------------------------------------------------+
echo.
echo  Starting BeaverKit...
timeout /t 2 /nobreak >nul
python main.py
if %errorlevel% neq 0 (
    echo  [!] Launch error. See message above.
    echo  [!] Contact: t.me/Beaver_kit
    pause
)

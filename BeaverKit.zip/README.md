# BeaverKit v3.0 — Release



---

## 🚀 Быстрая установка

### Windows
```
install.bat
```
*(Двойной клик по файлу)*

### Linux / macOS
```bash
chmod +x install.sh
./install.sh
```

---

## 📦 Зависимости

| Пакет | Назначение |
|-------|------------|
| Python 3.9+ | Основной язык |
| PyQt6 | Графический интерфейс |
| requests | HTTP-запросы |
| beautifulsoup4 | Парсинг HTML |
| psutil | Мониторинг системы |
| phonenumbers | Анализ телефонов |

---

## 🔧 Ручная установка

```bash
pip install PyQt6 requests beautifulsoup4 psutil phonenumbers
python main.py
```

Если ошибка `externally-managed-environment` (Arch/Manjaro):
```bash
pip install PyQt6 requests beautifulsoup4 psutil phonenumbers --break-system-packages
```

---

## 📱 Telegram
Канал: https://t.me/Beaver_kit

﻿@echo off
chcp 65001 >nul
title BeaverKit v3.0 - Install Dependencies
color 0A
cls

echo.
echo  ====================================================
echo      BeaverKit v3.0 - Install Dependencies
echo      t.me/Beaver_kit
echo  ====================================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [!] Python not found!
    echo      Download Python 3.9+ from python.org
    echo      Check "Add to PATH" during install.
    pause
    start https://www.python.org/downloads/
    exit /b 1
)
for /f "tokens=*" %%i in ('python --version') do echo  [OK] %%i found
echo.

echo  [1/4] Upgrading pip...
python -m pip install --upgrade pip --quiet --disable-pip-version-check
echo  [OK] pip upgraded
echo.

echo  [2/4] Installing PyQt6...
python -m pip install "PyQt6>=6.4" "PyQt6-Qt6>=6.4" "PyQt6-sip" --quiet
if %errorlevel% neq 0 python -m pip install "PyQt6>=6.4" --quiet --user
echo  [OK] PyQt6 installed
echo.

echo  [3/4] Installing libraries...
python -m pip install requests beautifulsoup4 psutil phonenumbers --quiet
if %errorlevel% neq 0 python -m pip install requests beautifulsoup4 psutil phonenumbers --quiet --user
echo  [OK] Libraries installed
echo.

echo  [4/4] Done!
echo.
echo  ====================================================
echo    All done. Run: python main.py
echo    or double-click install.bat
echo  ====================================================
echo.
pause
